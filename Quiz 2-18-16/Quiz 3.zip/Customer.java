public class Customer {

    private String customerName, address, email, creditCardInfo, shoppingInfo;
    private int phoneNo;

    public void register(){}
    public void login(){}
    public void updateProfile(){}

}
