public class Orders {

    private int orderId;
    private String dateCreated, dateShipped, customerName, customerId, status, shippingId;

    public void placeOrder(){}

}
