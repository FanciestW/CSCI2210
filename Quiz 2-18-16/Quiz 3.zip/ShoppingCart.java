public class ShoppingCart {

    private int cartId, productId, quantity, dateAdded;

    public void addCartItem(){}
    public void deleteCartItem(){}
    public void updateQuantity(){}
    public void viewCartDetail(){}
    public void checkout(){}

}
