/**
 * Created by William Lin on 3/3/2016.
 */
public class VIPCustomer extends Customer {

}
