/**
 * Created by wlin on 3/8/16.
 */
public class PromoKit {
    private VIPCustomer vip;

    Garment garment = new Garment();
    Video vid = new Video();
    Book book = new Book();
}
