/**
 * Created by wlin on 3/8/16.
 */
public class Client extends ShoppingCart{

    public static void main(String[] args){
        
    }

}
