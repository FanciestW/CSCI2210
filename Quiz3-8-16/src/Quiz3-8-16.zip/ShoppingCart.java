/**
 * Created by wlin on 3/8/16.
 */
public class ShoppingCart {
    //Composite relationships between ShoppingCart and Product, and Customer.
    Product prod = new Product();
    Customer customer = new Customer();
}
