public class Customer {

    //===========Private Class Attributes======================================
    private String customerName, address, email, creditCardInfo, shoppingInfo;
    private int phoneNo;
    //=========================================================================

    public void register(String customerName, String email){}

    public void login(){}

    public void updateProfile(){}

    public void updateCustomerName(String name){ this.customerName = name; }

    public String getCustomerName(){ return customerName; }

}
