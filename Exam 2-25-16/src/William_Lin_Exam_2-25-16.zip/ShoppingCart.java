public class ShoppingCart {

    //===========Private Class Attributes======================================
    private int cartId, productId, quantity, dateAdded;
    //=========================================================================

    public boolean addCartItem(int productId){} //Missing a boolean return

    public void deleteCartItem(){}

    public void updateQuantity(){}

    public void viewCartDetail(){}

    public void checkout(){}

}
