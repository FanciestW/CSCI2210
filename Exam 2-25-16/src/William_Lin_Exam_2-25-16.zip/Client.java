/**
 * Created by William on 2/25/2016.
 */
public class Client {

    public static void main(String[] args){
        Customer customer = new Customer();
        ShoppingCart cart = new ShoppingCart();
        Orders order = new Orders();
    }

}
